CREATE SCHEMA IF NOT EXISTS catalogs3.schsource WITH (location = 's3a://data/iris')
CREATE TABLE IF NOT EXISTS catalogs3.schsource.srcdata (
  sepal_length DOUBLE,
  sepal_width  DOUBLE,
  petal_length DOUBLE,
  petal_width  DOUBLE,
  class        VARCHAR
)   
WITH (
  external_location = 's3a://data/iris',
  format = 'PARQUET'
)

select * from catalogs3.schsource.srcdata limit 10

select count(*) as count from catalogs3.schsource.srcdata


CREATE SCHEMA IF NOT EXISTS catalogs3.offload WITH (location = 's3a://data/offload')
CREATE TABLE IF NOT EXISTS catalogs3.offload.table00 (
  sepal_length DOUBLE,
  sepal_width  DOUBLE,
  petal_length DOUBLE,
  petal_width  DOUBLE,
  class        VARCHAR
)   
WITH (
  external_location = 's3a://data/offload/data',
  format = 'PARQUET'
)

insert into catalogs3.offload.table00 select * from catalogs3.schsource.srcdata

select count(*) from catalogs3.offload.table00






CREATE SCHEMA IF NOT EXISTS mainframe.demmo WITH (location = 's3a://sparkartifact/')
CREATE TABLE IF NOT EXISTS mainframe.demmo.demo6 (
  item_key VARCHAR,
  item_binary_integer_2  VARCHAR,
  item_binary_integer_8 VARCHAR,
  item_binary_integer_10  VARCHAR
)   
WITH (
  external_location = 's3a://mainframe',
  format = 'CSV'
)
select * from rawcatalog.firstschema.source limit 10



# SERVICES
## DCP API

### EKS
```
k -n dcp cp /Users/bassim/Documents/dcpworkspace/dcpplatform/dcp-api/target/dcp-api-0.0.1-SNAPSHOT.jar dcpapi-dcpui-dcpui-0:/tmp/dcp-api.jar

k -n dcp exec -it dcpapi-dcpui-dcpui-0 -- bash

java -Dspring.config.location=/opt/dcp/conf/application.properties -jar /tmp/dcp-api.jar /opt/dcp/models/
```

### Openshift
```
k -n dreamrunner78-dev cp /Users/bassim/Documents/dcpworkspace/dcpplatform/dcp-api/target/dcp-api-0.0.1-SNAPSHOT.jar dcpapi-dcpui-dcpui-0:/tmp/dcp-api.jar

k -n dreamrunner78-dev exec -it dcpapi-dcpui-dcpui-0 -- bash

java -Dspring.config.location=/opt/dcp/conf/application.properties -jar /tmp/dcp-api.jar /opt/dcp/models/
```

## dcp sql activity
```
k -n dcp cp /Users/bassim/Documents/dcpworkspace/dcpplatform/dcp-sql-activity/target/dcp-sql-activity-0.0.1-SNAPSHOT.jar dcpapi-dcpui-dcpui-0:/tmp/dcp-sql.jar

k -n dcp cp /Users/bassim/Documents/dcp/setup/install/EKS/appli-sqlactivity.properties dcpapi-dcpui-dcpui-0:/tmp/appli-sqlactivity.properties

k -n dcp exec -it dcpapi-dcpui-dcpui-0 -- bash

java -Dspring.config.location=/tmp/appli-sqlactivity.properties -jar /tmp/dcp-sql.jar
```

## manual start  dcp gateway

### EKS
```
k -n dcp cp /Users/bassim/Documents/dcpworkspace/dcp-gateway/dcp-proxy/target/dcp-proxy-0.0.1-SNAPSHOT.jar dcpgateway-gateway-0:/tmp/dcp-proxy.jar

k -n dcp exec -it dcpgateway-gateway-0 -- bash

java -Dspring.config.location=/opt/trino/conf/application.yaml -jar /tmp/dcp-proxy.jar
java -Dspring.config.location=/tmp/application.yaml -jar /tmp/dcp-proxy.jar

k -n dcp cp /Users/bassim/Documents/dcpworkspace/dcp-gateway/dcp-sql-activity/target/dcp-sql-activity-0.0.1-SNAPSHOT.jar dcpgateway-gateway-0:/tmp/dcp-sql-gateway.jar

k -n dcp cp /Users/bassim/Documents/dcp/setup/install/EKS/dcp-gateway-sql-activity.yaml dcpgateway-gateway-0:/tmp/dcp-gateway-sql-activity.yaml
k -n dcp cp /Users/bassim/Documents/dcp/setup/install/MINIKUBE/dcp-gateway-sql-activity.yaml dcpgateway-gateway-0:/tmp/dcp-gateway-sql-activity.yaml

k -n dcp exec -it dcpgateway-gateway-0 -- bash

java -Dspring.config.location=/tmp/dcp-gateway-sql-activity.yaml -jar /tmp/dcp-sql-gateway.jar
```


### OPENSHIFT
```
k -n dreamrunner78-dev cp /Users/bassim/Documents/dcpworkspace/dcp-gateway/dcp-proxy/target/dcp-proxy-0.0.1-SNAPSHOT.jar dcpgateway-gateway-0:/tmp/dcp-proxy.jar

k -n dreamrunner78-dev exec -it dcpgateway-gateway-0 -- bash

java -Dspring.config.location=/opt/trino/conf/application.yaml -jar /tmp/dcp-proxy.jar


k -n dreamrunner78-dev cp /Users/bassim/Documents/dcpworkspace/dcp-gateway/dcp-sql-activity/target/dcp-sql-activity-0.0.1-SNAPSHOT.jar dcpgateway-gateway-0:/tmp/dcp-sql-gateway.jar

k -n dreamrunner78-dev cp /Users/bassim/Documents/dcp/setup/install/OPENSHIFT/dcp-gateway-sql-activity.yaml dcpgateway-gateway-0:/tmp/dcp-gateway-sql-activity.yaml

k -n dreamrunner78-dev exec -it dcpgateway-gateway-0 -- bash

java -Dspring.config.location=/tmp/dcp-gateway-sql-activity.yaml -jar /tmp/dcp-sql-gateway.jar
```

# Trino
## S3 Connector
```
CREATE SCHEMA IF NOT EXISTS oscatalog.firstschema WITH (location = 's3a://dcpirisdata/')
CREATE TABLE IF NOT EXISTS oscatalog.firstschema.source (
  sepal_length DOUBLE,
  sepal_width  DOUBLE,
  petal_length DOUBLE,
  petal_width  DOUBLE,
  class        VARCHAR
)   
WITH (
  external_location = 's3a://dcpirisdata/input',
  format = 'PARQUET'
)
select * from oscatalog.firstschema.source limit 10

CREATE SCHEMA IF NOT EXISTS oscatalog.sndschema WITH (location = 's3a://dcpirisdata/')
CREATE TABLE IF NOT EXISTS oscatalog.sndschema.destination (
  sepal_length DOUBLE,
  sepal_width  DOUBLE,
  petal_length DOUBLE,
  petal_width  DOUBLE,
  class        VARCHAR
)   
WITH (
  external_location = 's3a://dcpirisdata/output',
  format = 'PARQUET'
)
insert into oscatalog.sndschema.destination select * from oscatalog.firstschema.source
```

## Iceberg
```
CREATE SCHEMA IF NOT EXISTS iceberg01.offload WITH (location = 's3a://sparkartifact/')

CREATE TABLE iceberg.offload.customer
WITH (
  format = 'ORC',
  location = 's3a://dcpiceberg/pathcustomer/'
) 
AS SELECT * FROM tpch.tiny.customer

select * from iceberg.offload.customer limit 10

select * from iceberg.offload.customer order by custkey asc

  update iceberg.offload.customer set name='dcpdemo' where custkey=1
```

```
CREATE SCHEMA IF NOT EXISTS catice01.offload WITH (location = 's3a://teamaiceberg/')

CREATE TABLE catice01.offload.customer
WITH (
  format = 'ORC',
  location = 's3a://teamaiceberg/pathcustomer/'
) 
AS SELECT * FROM tpch.tiny.customer

select * from catice01.offload.customer limit 10

select * from iceberg.offload.customer order by custkey asc

update iceberg.offload.customer set name='dcpdemo' where custkey=1
```

## Bench cache
```
/opt/alluxio-2.10.0-SNAPSHOT/bin/alluxio fs mkdir /dcp

/opt/alluxio-2.10.0-SNAPSHOT/bin/alluxio fs mount \
  --option alluxio.underfs.s3.endpoint=http://dcpstorage-minio.dcp.svc.cluster.local:9000 \
  --option s3a.accessKeyId=admin \
  --option s3a.secretKey=Dcp2016. \
  --option alluxio.underfs.s3.disable.dns.buckets=true \
  /dcp/tpcds s3://dcpiceberg/

/opt/alluxio-2.10.0-SNAPSHOT/bin/alluxio fs chmod 777 /dcp

/opt/alluxio-2.10.0-SNAPSHOT/bin/alluxio fs chmod -R 777 /dcp

```

```
CREATE SCHEMA iceberg.bench WITH (location = 'alluxio://alluxio-master-0.dcp.svc.cluster.local:19998/dcp/tpcds/');
```

```
CREATE TABLE iceberg.bench.customer100
WITH (
  format = 'ORC',
  location = 'alluxio://alluxio-master-0.dcp.svc.cluster.local:19998/dcp/tpcds/customer100/'
) 
AS SELECT * FROM tpch.sf100.customer;
```
```
CREATE TABLE iceberg.bench.customer1000
WITH (
  format = 'ORC',
  location = 'alluxio://alluxio-master-0.dcp.svc.cluster.local:19998/dcp/tpcds/customer1000/'
) 
AS SELECT * FROM tpch.sf1000.customer;
```
```
CREATE TABLE iceberg.bench.customer10000
WITH (
  format = 'ORC',
  location = 'alluxio://alluxio-master-0.dcp.svc.cluster.local:19998/dcp/tpcds/customer10000/'
) 
AS SELECT * FROM tpch.sf10000.customer;
```

# Gateway
## Certificate
```
cd /Users/bassim/Documents/dcp/demos/tmp/gateway
https://dcpgateway-dreamrunner78-dev.apps.sandbox-m2.ll9k.p1.openshiftapps.com
openssl s_client -showcerts -servername dcpgateway-dreamrunner78-dev.apps.sandbox-m2.ll9k.p1.openshiftapps.com -connect dcpgateway-dreamrunner78-dev.apps.sandbox-m2.ll9k.p1.openshiftapps.com:443 2>/dev/null </dev/null |  sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > dcp.crt

openssl s_client -showcerts -servername ossql.apps.sandbox-m2.ll9k.p1.openshiftapps.com -connect ossql.apps.sandbox-m2.ll9k.p1.openshiftapps.com:443 2>/dev/null </dev/null |  sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > dcp.crt

keytool -noprompt  -import -file dcp.crt \
    -keystore truststore.jks \
    -storepass "bassim" \
    -noprompt

export JAVA_HOME=/Users/bassim/Documents/tools/jdk-17.0.5.jdk/Contents/Home

openssl s_client -showcerts -servername dcpgateway.dcp-technologies.com -connect dcpgateway.dcp-technologies.com:443 2>/dev/null </dev/null |  sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > dcp.crt

keytool -noprompt  -import -file dcp.crt \
    -keystore truststore.jks \
    -storepass "bassim" \
    -noprompt

/Users/bassim/Documents/Platform/Automation/setup-query-platform/binairies/trino-cli-414-executable.jar \
--server https://dcpgateway.dcp-technologies.com --truststore-path /Users/bassim/Documents/dcp/demos/tmp/gateway/truststore.jks  \
--truststore-password bassim --user test --password

/Users/bassim/Documents/Platform/Automation/setup-query-platform/binairies/trino-cli-414-executable.jar \
--server https://dcpgateway.dcp-technologies.com --truststore-path /Users/bassim/Documents/dcp/demos/tmp/gateway/truststore.jks  \
--truststore-password bassim --source etl --user test --password

/Users/bassim/Documents/Platform/Automation/setup-query-platform/binairies/trino-cli-414-executable.jar \
--server https://dcpgateway-dreamrunner78-dev.apps.sandbox-m2.ll9k.p1.openshiftapps.com --truststore-path /Users/bassim/Documents/dcp/demos/tmp/gateway/openshift/truststore.jks  \
--truststore-password bassim --user test --password


/Users/bassim/Documents/Platform/Automation/setup-query-platform/binairies/trino-cli-414-executable.jar \
--server https://ossql.apps.sandbox-m2.ll9k.p1.openshiftapps.com --truststore-path /Users/bassim/Documents/dcp/demos/tmp/gateway/openshift/api/truststore.jks  \
--truststore-password bassim --user test --password
```



# Auto scaler
```
kubectl -n team-a apply -f /Users/bassim/Documents/dcp/study/keda/scaled-trino-eks.yaml

export JAVA_HOME=/Users/bassim/Documents/tools/jdk-17.0.5.jdk/Contents/Home

/Users/bassim/Documents/Platform/Automation/setup-query-platform/binairies/trino-cli-414-executable.jar \
--server https://sqla.dcp-technologies.com --truststore-path /Users/bassim/Documents/dcp/demos/tmp/gateway/truststore.jks  \
--truststore-password bassim --user user1 --password
```







openssl s_client -showcerts -servername query.apps.rhodcp01.7jdf.p1.openshiftapps.com -connect query.apps.rhodcp01.7jdf.p1.openshiftapps.com:443 2>/dev/null </dev/null | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > /Users/bassim/Documents/dcp/study/tmp/sql/sql.cert

export JAVA_HOME=/Users/bassim/Documents/tools/jdk-17.0.5.jdk/Contents/Home

keytool -noprompt  -import -file /Users/bassim/Documents/dcp/study/tmp/sql/sql.cert \
    -keystore /Users/bassim/Documents/dcp/study/tmp/sql/truststore.jks \
    -storepass "dcpsqltest" \
    -noprompt





export JAVA_HOME=/Users/bassim/Documents/tools/jdk-17.0.5.jdk/Contents/Home

openssl s_client -showcerts -servername prestodb-prestodbpiywbn-svc.demo.svc.cluster.local -connect prestodb-prestodbpiywbn-svc.demo.svc.cluster.local:8443 2>/dev/null </dev/null |  sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > dcp.crt

keytool -noprompt  -import -file dcp.crt \
    -keystore truststore.jks \
    -storepass "bassim" \
    -noprompt


openssl s_client -showcerts -servername ldap.dcp.svc.cluster.local -connect ldap.dcp.svc.cluster.local:1636 2>/dev/null </dev/null |  sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p'



CREATE SCHEMA IF NOT EXISTS cats3.schsource WITH (location = 's3a://data/taxi')
drop table cats3.schsource.nyc_taxi_yellow
CREATE TABLE IF NOT EXISTS cats3.schsource.nyc_taxi_yellow (
    vendor_id int,
    pickup_time timestamp,
    pickup_location_id int,
    dropoff_time timestamp,
    dropoff_location_id int,
    passenger_count double,
    trip_distance double,
    ratecode_id int,
    payment_type int,
    total_amount double,
    fare_amount double,
    tip_amount double,
    tolls_amount double,
    mta_tax double,
    improvement_surcharge double,
    congestion_surcharge double,
    airport_fee double,
    extra_surcharges double
)   
WITH (
  external_location = 's3a://data/taxi',
  format = 'PARQUET'
)

select * from cats3.schsource.nyc_taxi_yellow limit 10 