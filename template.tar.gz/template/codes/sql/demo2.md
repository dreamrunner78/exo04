CREATE SCHEMA IF NOT EXISTS cats3.schsource WITH (location = 's3a://sparklog/iris');
CREATE TABLE IF NOT EXISTS cats3.schsource.srcdata (
  sepal_length DOUBLE,
  sepal_width  DOUBLE,
  petal_length DOUBLE,
  petal_width  DOUBLE,
  class        VARCHAR
);  
WITH (
  external_location = 's3a://sparklog/iris',
  format = 'PARQUET'
);
select * from cats3.schsource.srcdata limit 10;


CREATE SCHEMA IF NOT EXISTS iceberg01.offloadiris WITH (location = 's3a://dcp-data-bucket/iris');

CREATE TABLE iceberg01.offloadiris.irisoffload
WITH (
  format = 'ORC',
  location = 's3a://dcp-data-bucket/iris/'
) 
AS select * from cats3.schsource.srcdata;

select * from iceberg01.offloadiris.irisoffload;



CREATE SCHEMA IF NOT EXISTS iceberg01.offload WITH (location = 's3a://dcp-data-bucket/');

CREATE TABLE iceberg01.offload.customer
WITH (
  format = 'ORC',
  location = 's3a://dcp-data-bucket/pathcustomer/'
) 
AS SELECT * FROM tpch.tiny.customer;

select * from iceberg01.offload.customer limit 10

select * from iceberg01.offload.customer order by custkey asc

update iceberg01.offload.customer set name='dcpdemo' where custkey=1









CREATE SCHEMA iceberg01.bench1 WITH (location = 'alluxio://cacheqtcdcs-master-0.demo.svc.cluster.local:19998/dcpdatabucket/customer1/');
CREATE TABLE iceberg01.bench1.customer1
WITH (
  format = 'ORC',
  location = 'alluxio://cacheqtcdcs-master-0.demo.svc.cluster.local:19998/dcpdatabucket/customer1/'
) 
AS select * from tpch.sf1.customer;

CREATE SCHEMA iceberg01.bench2 WITH (location = 'alluxio://cacheqtcdcs-master-0.demo.svc.cluster.local:19998/dcpdatabucket/customer2/');

CREATE TABLE iceberg01.bench2.customer2
WITH (
  format = 'ORC',
  location = 'alluxio://cacheqtcdcs-master-0.demo.svc.cluster.local:19998/dcpdatabucket/customer2/'
) 
AS select * from tpch.sf10.customer;
