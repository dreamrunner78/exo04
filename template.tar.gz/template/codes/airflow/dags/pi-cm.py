from airflow import DAG
from datetime import datetime, timedelta
from airflow.contrib.operators.kubernetes_pod_operator import KubernetesPodOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.providers.trino.operators.trino import TrinoOperator
from kubernetes.client import models as k8s
from airflow.utils.task_group import TaskGroup

# START HEADER
compute_resources_good_awtfju=k8s.V1ResourceRequirements(
    requests={
        'cpu': '100m',
        'memory': '128Mi'
    },
    limits={
        'cpu': '500m',
        'memory': '512Mi'
    }
)

#SPARK TEMPLATE
vm_sparktemplate_good_awtfju = k8s.V1VolumeMount(
  mount_path="/opt/spark/template", 
  name="sparktemplate", 
  sub_path=None, 
  read_only=False
)
v_sparktemplate_tmp_good_awtfju = k8s.V1Volume(
    name="sparktemplate",
    empty_dir=k8s.V1EmptyDirVolumeSource()
)

#PASSWD
volume_config_passwd_good_awtfju = k8s.V1ConfigMapVolumeSource(
  name='dcp-passwd-good-cm'
)
volume_mount_passwd_good_awtfju = k8s.V1VolumeMount(
  mount_path='/etc/passwd', 
  name='passwd', 
  sub_path='passwd', 
  read_only=False
)
volume_passwd_good_awtfju = k8s.V1Volume(
    name='passwd', 
    config_map=volume_config_passwd_good_awtfju
)

#TMP DIRECTORY
volume_mount_tmpdir_good_awtfju = k8s.V1VolumeMount(
  mount_path="/tmp", 
  name="tmp", 
  sub_path=None, 
  read_only=False
)
volume_tmpdir_good_awtfju = k8s.V1Volume(
    name="tmp",
    empty_dir=k8s.V1EmptyDirVolumeSource()
)
#FINAL CACERT
volume_mount_finalcacert_good_awtfju = k8s.V1VolumeMount(
  mount_path="/opt/finalcacert", 
  name="finalcacert", 
  sub_path=None, 
  read_only=False
)
volume_finalcacet_good_awtfju = k8s.V1Volume(
    name="finalcacert",
    empty_dir=k8s.V1EmptyDirVolumeSource()
)

#CERTIFICATE CONFIGMAP
volume_config_cert_good_awtfju = k8s.V1ConfigMapVolumeSource(
  name='dcp-addcert-good-cm'
)
volume_mount_cert_awtfju = k8s.V1VolumeMount(
  mount_path='/opt/addcert', 
  name='addcert',
  read_only=False
)
volume_cert_good_awtfju = k8s.V1Volume(
    name='addcert', 
    config_map=volume_config_cert_good_awtfju
)

init_container_good = k8s.V1Container(
    name="dcp-spark-template-good-awtfju",
    image="docker.io/dcptechnologies/spark:350-j17p3h3",
    volume_mounts=[vm_sparktemplate_good_awtfju, volume_mount_cert_awtfju, volume_mount_finalcacert_good_awtfju],
    command=["sh", "-c"],
    args=["""
cp $JAVA_HOME/lib/security/cacerts /opt/finalcacert/cacerts
chmod 777 /opt/finalcacert/cacerts
keytool -import -noprompt -trustcacerts -alias store_3 -file /opt/addcert/store_3 -keystore /opt/finalcacert/cacerts -storepass changeit
cat << EOF > /opt/spark/template/driver.yaml
apiVersion: v1
kind: Pod       
metadata:
  annotations:
spec:
  selector:
    matchLabels:
      master-cloud-provider: "local"
      master-release: "master-spark-application"
      managed-by: "dcp"
      master-application-name: "good"
      master-application-type: "spark"
      master-workspace: "default"
      idprovider: "1"
      provider: "local"
  schedulerName: ""
  priorityClassName: ""
  affinity: {}
  
  volumes:
    - name: passwd
      configMap:
        name: dcp-passwd-good-cm
    - name: finalcacert
      emptyDir: {}
    - name: addcert
      configMap:
        name: dcp-addcert-good-cm

  securityContext:
    runAsNonRoot: true
    runAsUser: 1001010000
    fsGroup: 1001010000
  initContainers:
    - name: dcp-good-ic-driver-awtfju
      image: docker.io/dcptechnologies/java:17-jre
      imagePullPolicy: "IfNotPresent"
      command:
        - sh
        - -c
        - |
          cp $JAVA_HOME/lib/security/cacerts /opt/finalcacert/cacerts
          chmod 777 /opt/finalcacert/cacerts
          keytool -import -noprompt -trustcacerts -alias dcp-store_3 -file /opt/addcert/store_3 -keystore /opt/finalcacert/cacerts -storepass changeit
      securityContext:
        runAsNonRoot: true
        runAsUser: 1001010000
        allowPrivilegeEscalation: false
        seccompProfile:
          type: RuntimeDefault
        capabilities:
          drop: ["ALL"]
      volumeMounts:
        - name: finalcacert
          mountPath: /opt/finalcacert
        - name: addcert
          mountPath: /opt/addcert
  containers:
    - name: dcp-good-c-driver-awtfju
      securityContext:
        runAsNonRoot: true
        runAsUser: 1001010000
        allowPrivilegeEscalation: false
        seccompProfile:
          type: RuntimeDefault
        capabilities:
          drop: ["ALL"]
      env:
      volumeMounts:
        - name:  finalcacert
          mountPath: /opt/finalcacert
        - name: addcert
          mountPath: /opt/addcert
        - name: passwd
          mountPath: /etc/passwd
          subPath: passwd
EOF
cat << EOF > /opt/spark/template/executor.yaml
apiVersion: v1
kind: Pod
metadata:    
  annotations:
spec:
  selector:
    matchLabels:
      master-cloud-provider: "local"
      master-release: "master-spark-application"
      managed-by: "dcp"
      master-application-name: "good"
      master-application-type: "spark"
      master-workspace: "default"
      idprovider: "1"
      provider: "local"

  schedulerName: ""
  affinity: {}
  
  volumes:
    - name: passwd
      configMap:
        name: dcp-passwd-good-cm
    - name: finalcacert
      emptyDir: {}
    - name: addcert
      configMap:
        name: dcp-addcert-good-cm

  securityContext:
    runAsNonRoot: true
    runAsUser: 1001010000
    fsGroup: 1001010000
  initContainers:
    - name: dcp-good-ic-exec-awtfju
      image: docker.io/dcptechnologies/java:17-jre
      imagePullPolicy: "IfNotPresent"
      command:
        - sh
        - -c
        - |
          cp $JAVA_HOME/lib/security/cacerts /opt/finalcacert/cacerts
          chmod 777 /opt/finalcacert/cacerts
          keytool -import -noprompt -trustcacerts -alias dcp-store_3 -file /opt/addcert/store_3 -keystore /opt/finalcacert/cacerts -storepass changeit
      securityContext:
        runAsNonRoot: true
        runAsUser: 1001010000
        allowPrivilegeEscalation: false
        seccompProfile:
          type: RuntimeDefault
        capabilities:
          drop: ["ALL"]
      volumeMounts:
        - name: finalcacert
          mountPath: /opt/finalcacert
        - name: addcert
          mountPath: /opt/addcert
  containers:
    - name: dcp-good-exec-c-awtfju
      securityContext:
        runAsNonRoot: true
        runAsUser: 1001010000
        allowPrivilegeEscalation: false
        seccompProfile:
          type: RuntimeDefault
        capabilities:
          drop: ["ALL"]
      env:
      volumeMounts:
        - name:  finalcacert
          mountPath: /opt/finalcacert
        - name: addcert
          mountPath: /opt/addcert
        - name: passwd
          mountPath: /etc/passwd
          subPath: passwd
EOF
    """],
)
# END HEADER

default_args = {
    'owner': 'dcp',
    'depends_on_past': True,    
    'start_date': datetime(2023, 1, 1),
    'retries': 1,
    'retry_delay': timedelta(minutes=10),
}
with DAG(
    dag_id='sparkjob_good', 
    default_args=default_args,
    schedule_interval=None,
    catchup=False) as dag:

# START TASK
    good = KubernetesPodOperator(namespace='demo',
    image="docker.io/dcptechnologies/spark:350-j17p3h3",
    image_pull_secrets=[k8s.V1LocalObjectReference("dcpregistry")],
    cmds=[
    "sh",
    "-c",
    'java    -Dcom.amazonaws.sdk.disableCertChecking=true -Djavax.net.ssl.trustStore=/opt/finalcacert/cacerts -Djavax.net.ssl.trustStorePassword=changeit   -cp /opt/spark/conf:/opt/spark/jars/* -XX:+IgnoreUnrecognizedVMOptions --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.lang.invoke=ALL-UNNAMED --add-opens=java.base/java.lang.reflect=ALL-UNNAMED --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.base/java.net=ALL-UNNAMED --add-opens=java.base/java.nio=ALL-UNNAMED --add-opens=java.base/java.util=ALL-UNNAMED --add-opens=java.base/java.util.concurrent=ALL-UNNAMED --add-opens=java.base/java.util.concurrent.atomic=ALL-UNNAMED --add-opens=java.base/sun.nio.ch=ALL-UNNAMED --add-opens=java.base/sun.nio.cs=ALL-UNNAMED --add-opens=java.base/sun.security.action=ALL-UNNAMED --add-opens=java.base/sun.util.calendar=ALL-UNNAMED --add-opens=java.security.jgss/sun.security.krb5=ALL-UNNAMED org.apache.spark.deploy.SparkSubmit --deploy-mode cluster --verbose --conf spark.master=k8s://https://10.96.0.1:443 --conf spark.app.name=dcp-good-awtfju --conf spark.jars.ivy=/tmp --conf spark.kubernetes.file.upload.path=file:///opt/spark/work-dir --conf spark.kubernetes.submission.waitAppCompletion=true --conf spark.kubernetes.report.interval=1s --conf spark.kubernetes.namespace=demo --conf spark.kubernetes.container.image=docker.io/dcptechnologies/spark:350-j17p3h3 --conf spark.kubernetes.container.image.pullPolicy=IfNotPresent --conf spark.kubernetes.container.image.pullSecrets=dcpregistry --conf spark.kubernetes.authenticate.serviceAccountName=good-sa --conf spark.kubernetes.driver.podTemplateFile=/opt/spark/template/driver.yaml --conf spark.kubernetes.executor.podTemplateFile=/opt/spark/template/executor.yaml --conf spark.hadoop.fs.s3a.bucket.dcp-data-bucket.aws.credentials.provider=org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider --conf spark.hadoop.fs.s3a.bucket.dcp-data-bucket.impl=org.apache.hadoop.fs.s3a.S3AFileSystem --conf spark.hadoop.fs.s3a.bucket.dcp-data-bucket.change.detection.version.require=false --conf spark.hadoop.fs.s3a.bucket.dcp-data-bucket.access.key=admin --conf spark.hadoop.fs.s3a.bucket.dcp-data-bucket.secret.key=DcpAdminPassword2016. --conf spark.hadoop.fs.s3a.bucket.dcp-data-bucket.endpoint=https://masterstorage-minio.dcp.svc.cluster.local:9000 --conf spark.hadoop.fs.s3a.bucket.dcp-data-bucket.path.style.access=true --conf spark.hadoop.fs.s3a.bucket.dcp-data-bucket.signing-algorithm=S3SignerType --conf spark.hadoop.fs.s3a.bucket.dcp-data-bucket.connection.ssl.enabled=true --conf spark.hadoop.fs.s3a.connection.timeout=1200000 --conf spark.hadoop.fs.s3a.connection.maximum=200 --conf spark.hadoop.fs.s3a.fast.upload=true --conf spark.hadoop.fs.s3a.readahead.range=256K --conf spark.hadoop.fs.s3a.input.fadvise=random --conf spark.hadoop.fs.s3a.impl=org.apache.hadoop.fs.s3a.S3AFileSystem --conf spark.hadoop.fs.s3a.bucket.sparkartifact.aws.credentials.provider=org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider --conf spark.hadoop.fs.s3a.bucket.sparkartifact.impl=org.apache.hadoop.fs.s3a.S3AFileSystem --conf spark.hadoop.fs.s3a.bucket.sparkartifact.change.detection.version.require=false --conf spark.hadoop.fs.s3a.bucket.sparkartifact.access.key=admin --conf spark.hadoop.fs.s3a.bucket.sparkartifact.secret.key=DcpAdminPassword2016. --conf spark.hadoop.fs.s3a.bucket.sparkartifact.endpoint=https://masterstorage-minio.dcp.svc.cluster.local:9000 --conf spark.hadoop.fs.s3a.bucket.sparkartifact.path.style.access=true --conf spark.hadoop.fs.s3a.bucket.sparkartifact.signing-algorithm=S3SignerType --conf spark.hadoop.fs.s3a.bucket.sparkartifact.connection.ssl.enabled=true --conf spark.hadoop.fs.s3a.connection.timeout=1200000 --conf spark.hadoop.fs.s3a.connection.maximum=200 --conf spark.hadoop.fs.s3a.fast.upload=true --conf spark.hadoop.fs.s3a.readahead.range=256K --conf spark.hadoop.fs.s3a.input.fadvise=random --conf spark.hadoop.fs.s3a.impl=org.apache.hadoop.fs.s3a.S3AFileSystem --conf spark.kubernetes.driver.pod.name=dcp-good-driver-awtfju --conf spark.kubernetes.driver.label.master-cloud-provider=local --conf spark.kubernetes.driver.label.master-release=master-spark-application --conf spark.kubernetes.driver.label.managed-by=dcp --conf spark.kubernetes.driver.label.master-application-name=good --conf spark.kubernetes.driver.label.master-application-type=spark --conf spark.kubernetes.driver.label.master-workspace=default --conf spark.kubernetes.driver.label.idprovider=1 --conf spark.kubernetes.driver.label.provider=local --conf spark.kubernetes.driver.annotation.dcp-cloud-provider=local --conf spark.driver.memoryOverheadFactor=0.1 --conf spark.kubernetes.authenticate.driver.serviceAccountName=good-sa --conf spark.kubernetes.driver.request.cores=1 --conf spark.kubernetes.driver.limit.cores=2 --conf spark.driver.memory=1g --conf spark.driver.extraJavaOptions=" -Dcom.amazonaws.sdk.disableCertChecking=true -Djavax.net.ssl.trustStore=/opt/finalcacert/cacerts -Djavax.net.ssl.trustStorePassword=changeit " --conf spark.kubernetes.driver.volumes.emptyDir.data.mount.path=/opt/spark/work-dir --conf spark.kubernetes.driver.volumes.emptyDir.data.mount.readOnly=false --conf spark.kubernetes.driver.volumes.emptyDir.tmp.mount.path=/tmp --conf spark.kubernetes.driver.volumes.emptyDir.tmp.mount.readOnly=false --conf spark.kubernetes.executor.podNamePrefix=dcp-good-executor-awtfju --conf spark.kubernetes.executor.label.master-cloud-provider=local --conf spark.kubernetes.executor.label.master-release=master-spark-application --conf spark.kubernetes.executor.label.managed-by=dcp --conf spark.kubernetes.executor.label.master-application-name=good --conf spark.kubernetes.executor.label.master-application-type=spark --conf spark.kubernetes.executor.label.master-workspace=default --conf spark.kubernetes.executor.label.idprovider=1 --conf spark.kubernetes.executor.label.provider=local --conf spark.kubernetes.executor.annotation.dcp-cloud-provider=local --conf spark.executor.memoryOverheadFactor=0.1 --conf spark.kubernetes.authenticate.executor.serviceAccountName=good-sa --conf spark.executor.instances=1 --conf spark.kubernetes.executor.request.cores=1 --conf spark.kubernetes.executor.limit.cores=2 --conf spark.executor.memory=1g --conf spark.executor.extraJavaOptions=" -Dcom.amazonaws.sdk.disableCertChecking=true -Djavax.net.ssl.trustStore=/opt/finalcacert/cacerts -Djavax.net.ssl.trustStorePassword=changeit " --conf spark.kubernetes.executor.volumes.emptyDir.data.mount.path=/opt/spark/work-dir --conf spark.kubernetes.executor.volumes.emptyDir.data.mount.readOnly=false --conf spark.kubernetes.executor.volumes.emptyDir.tmp.mount.path=/tmp --conf spark.kubernetes.executor.volumes.emptyDir.tmp.mount.readOnly=false --conf spark.speculation=false --conf spark.network.timeout=2400 --class org.apache.spark.examples.SparkPi s3a://sparkartifact/examplles350/spark-examples_2.12-3.5.0.jar 500'
    ],
    name="dcp-good-launcher-awtfju",
    task_id="dcp-spark-task-good-awtfju",
    env_vars={
    "SPARK_WORKER_DIR": "/opt/spark/work-dir"
    },
    schedulername='',
    init_containers=[init_container_good],
    volume_mounts=[vm_sparktemplate_good_awtfju, volume_mount_passwd_good_awtfju, volume_mount_tmpdir_good_awtfju, volume_mount_finalcacert_good_awtfju, volume_mount_cert_awtfju],
    volumes=[v_sparktemplate_tmp_good_awtfju, volume_passwd_good_awtfju, volume_tmpdir_good_awtfju, volume_finalcacet_good_awtfju, volume_cert_good_awtfju],
    service_account_name='good-sa',
    labels={
    "master-cloud-provider":"local",
    "master-release":"master-spark-application",
    "managed-by":"dcp",
    "master-application-name":"good",
    "master-application-type":"spark",
    "master-workspace":"default",
    "idprovider":"1",
    "provider":"local"
    },
    security_context={
    "runAsNonRoot": True,
    "runAsUser": 1001010000,
    "allowPrivilegeEscalation": False,
    "seccompProfile":{
        "type": "RuntimeDefault"
    },
    "capabilities": {
        'drop': '["ALL"]'
    }
    },
    container_resources=compute_resources_good_awtfju,
    get_logs=True,
    dag=dag
    )
    good_start= DummyOperator(task_id='good_start', dag=dag)
    good_end= DummyOperator(task_id='good_end', dag=dag)
# END TASK

# START EDGE
    good_start.set_downstream(good)
    good.set_downstream(good_end)
# END EDGE