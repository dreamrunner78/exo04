/opt/alluxio-2.10.0-SNAPSHOT/bin/alluxio fs mount \
--shared \
--option alluxio.underfs.s3.endpoint=https://masterstorage-minio.dcp.svc.cluster.local:9000 \
--option s3a.accessKeyId=admin \
--option s3a.secretKey=DcpAdminPassword2016. \
--option alluxio.underfs.s3.disable.dns.buckets=true \
--option alluxio.underfs.s3.secure.http.enabled=true \
--option alluxio.underfs.s3.signer.algorithm=S3SignerType \
/mnt s3a://test