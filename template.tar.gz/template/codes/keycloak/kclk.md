curl -v -k 'https://kclktdemo.apps.sandbox-m2.ll9k.p1.openshiftapps.com/realms/demo/protocol/openid-connect/token'  \
-H 'Content-Type: application/x-www-form-urlencoded' \
--data-urlencode 'client_id=sphstixckw' \
--data-urlencode "client_secret=xHMRMvgPiW7UKArm7snHBqS7wlcM0OfT" \
--data-urlencode 'grant_type=password' \
--data-urlencode 'username=julia' \
--data-urlencode 'password=julia1234'