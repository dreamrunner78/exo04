# A simple example to demo preemption.

## Steps:
```shell script
cd example
NAMESPACE=demo
kubectl -n $NAMESPACE apply -f low-priority-job-outside-fence.yaml
kubectl -n $NAMESPACE apply -f low-priority-job.yaml
kubectl -n $NAMESPACE get pods | grep Running
# Should have 10 pods in Running.
# (5 outside fence, 5 low-priority)

kubectl -n $NAMESPACE apply -f normal-priority-job.yaml
kubectl -n $NAMESPACE get pods | grep Running
# Wait 1~2 minutes for preemption to occur.
# (5 outside fence, 2 low-priority, 3 normal-priority)

kubectl -n $NAMESPACE delete -f low-priority-job.yaml
kubectl -n $NAMESPACE get pods | grep Running
# (5 outside fence, 5 normal-priority)

kubectl -n $NAMESPACE apply -f high-priority-job.yaml
kubectl -n $NAMESPACE get pods | grep Running
# Wait 1~2 minutes for preemption to occur.
# (5 outside fence, 3 normal-priority, 2 high-priority)

kubectl -n $NAMESPACE delete -f normal-priority-job.yaml
kubectl -n $NAMESPACE get pods | grep Running
# (5 outside fence, 5 high-priority)

kubectl -n $NAMESPACE apply -f normal-priority-job-with-9999-priority-class.yaml
kubectl -n $NAMESPACE get pods | grep Running

# Wait 1~2 minutes for preemption to occur.
# (5 outside fence, 3 high-priority, 2 normal-priority-job-with-9999-priority-class)

#cleanup
kubectl -n $NAMESPACE delete -f high-priority-job.yaml 
kubectl -n $NAMESPACE delete -f normal-priority-job-with-9999-priority-class.yaml
kubectl -n $NAMESPACE delete -f low-priority-job-outside-fence.yaml
```