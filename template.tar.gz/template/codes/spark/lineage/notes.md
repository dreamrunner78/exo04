--conf spark.jars.packages=io.openlineage:openlineage-spark_2.12:1.10.2 \
--conf spark.extraListeners=io.openlineage.spark.agent.OpenLineageSparkListener \
--conf spark.openlineage.transport.url=http://marquez.dcp.svc.cluster.local:8087 \
--conf spark.openlineage.host=http://marquez.dcp.svc.cluster.local:8087 \
--conf spark.openlineage.namespace=pyspark \
--conf spark.openlineage.transport.type=http \





spark.jars.packages=io.openlineage:openlineage-spark_2.12:1.10.2    
spark.extraListeners=io.openlineage.spark.agent.OpenLineageSparkListener
spark.openlineage.transport.url=http://marquez.dcp.svc.cluster.local:8087
spark.openlineage.host=http://marquez.dcp.svc.cluster.local:8087
spark.openlineage.namespace=job01
spark.openlineage.transport.type=http



spark.jars.packages=io.openlineage:openlineage-spark_2.12:1.10.2    
spark.extraListeners=io.openlineage.spark.agent.OpenLineageSparkListener
spark.openlineage.transport.url=http://marquez.dcp.svc.cluster.local:8087
spark.openlineage.host=http://marquez.dcp.svc.cluster.local:8087
spark.openlineage.namespace=job01
spark.openlineage.transport.type=http