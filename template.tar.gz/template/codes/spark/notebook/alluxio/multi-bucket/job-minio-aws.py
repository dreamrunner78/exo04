from ipynb.fs.full.sparkconf  import get_spark_session
from pyspark import SparkConf

from pyspark.sql import SparkSession
from pyspark.context import SparkContext
from pyspark.sql.functions import *
from pyspark.sql import functions as f
import logging
import sys
import time
from datetime import datetime

conf=SparkConf()
spark = get_spark_session("demo", conf)

print(conf.toDebugString())

source = spark.read.orc('s3a://dcp-raw-data/derived/customer/orc/data')

source.printSchema()

source.createOrReplaceTempView('customerorc')


spark.sql('select * from customerorc').show()

newsource = source.withColumn("current_date", f.lit(datetime.now()))

newsource.printSchema()

newsource.createOrReplaceTempView('newsource')

spark.sql("select current_date from newsource").show()


repeated = newsource.sample(False, 0.5, seed=0)

repeated.show()
for _ in range(int(4)):
    newsource = newsource.union(repeated)

newsource.repartition(2).write.mode("overwrite").orc("s3a://dcp-offload-data/exposition/customer")
newsource.repartition(2).write.mode("overwrite").orc("s3a://demodcp01/exposition/customer")

spark.stop()