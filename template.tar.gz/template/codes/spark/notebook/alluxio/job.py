from ipynb.fs.full.sparkconf  import get_spark_session
from pyspark import SparkConf

from pyspark.sql import SparkSession
from pyspark.context import SparkContext
from pyspark.sql.functions import *
from pyspark.sql import functions as f
import logging
import sys
import time
from datetime import datetime



conf=SparkConf()
spark = get_spark_session("demo", conf)


source = spark.read.orc('s3a://dcp-data-bucket/customer1/data/20240424_211238_00029_ppumv-fe4724b2-d1ae-42ea-85ae-3acdc3e2f4d9.orc')

source.printSchema()

source.createOrReplaceTempView('sourceTable')

spark.sql('select * from sourceTable').show()

cache = spark.read.orc('alluxio://cacheqtcdcs-master-0.demo.svc.cluster.local:19998/dcpdatabucket/customer4/data')

cache.show()

spark.stop()