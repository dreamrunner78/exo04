from ipynb.fs.full.sparkconf  import get_spark_session
from pyspark import SparkConf

from pyspark.sql import SparkSession
from pyspark.context import SparkContext
from pyspark.sql.functions import *
from pyspark.sql import functions as f
import logging
import sys
import time
from datetime import datetime

conf=SparkConf()
print(conf.toDebugString())
spark = get_spark_session("demo", conf)

source = spark.read.parquet('s3a://dcp-raw-data/taxi/yellow_tripdata_2022-01.parquet')

source.printSchema()

source.createOrReplaceTempView('sourceTable')
result = spark.sql('select * from sourceTable')
print(result)

result.write.mode("overwrite").orc('s3a://dcp-raw-data/output')