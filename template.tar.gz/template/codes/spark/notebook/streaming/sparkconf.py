import os

from pyspark import SparkConf
from pyspark.sql import SparkSession

HOST = os.getenv('KUBERNETES_SERVICE_HOST')
PORT = os.getenv('KUBERNETES_SERVICE_PORT')

config = {
    "spark.kubernetes.namespace": "demo",
    "spark.kubernetes.container.image": "docker.io/dcptechnologies/notebook:342-j17p3h3-6.2.0",
    "spark.executor.instances": "1",
    "spark.executor.memory": "1g",
    "spark.executor.cores": "1",
    "spark.driver.blockManager.port": "7777",
    "spark.driver.port": "2222",
    "spark.kubernetes.container.image.pullSecrets": "dcpregistry",
    "spark.kubernetes.executor.label.dcp-release": "dcp-single-notebook",
    "spark.kubernetes.executor.label.managed-by": "dcp",
    "spark.kubernetes.executor.label.dcp-app-name": "nb",
    

    "spark.kubernetes.driver.request.cores": "1",
    "spark.kubernetes.driver.limit.cores": "2",
    "spark.kubernetes.driver.volumes.emptyDir.tmp.mount.path": "/tmp",
    "spark.kubernetes.driver.volumes.emptyDir.tmp.mount.readOnly": "false",
    "spark.kubernetes.driver.volumes.emptyDir.work.mount.path": "/opt/spark/work-dir",
    "spark.kubernetes.driver.volumes.emptyDir.work.mount.readOnly": "false",

    "spark.executor.instances": "1",
    "spark.executor.memory": "1024m",
    "spark.executor.cores": "1",
    "spark.kubernetes.executor.limit.cores": "2",
    "spark.kubernetes.executor.podTemplateFile": "/opt/dcp/conf/executor.yaml",
    "spark.kubernetes.executor.volumes.emptyDir.tmp.mount.path": "/tmp",
    "spark.kubernetes.executor.volumes.emptyDir.tmp.mount.readOnly": "false",
    "spark.kubernetes.executor.volumes.emptyDir.work.mount.path": "/opt/spark/work-dir",
    "spark.kubernetes.executor.volumes.emptyDir.work.mount.readOnly": "false",
    
    "spark.hadoop.fs.s3a.aws.credentials.provider": "org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider",
    "spark.hadoop.fs.s3a.impl": "org.apache.hadoop.fs.s3a.S3AFileSystem",
    "spark.hadoop.fs.s3a.change.detection.version.require": "false",
    "spark.hadoop.fs.s3a.access.key": "admin",
    "spark.hadoop.fs.s3a.secret.key": "DcpAdminPassword2016.",
    "spark.hadoop.fs.s3a.endpoint": "https://masterstorage-minio.dcpsoftware.svc.cluster.local:9000",
    "spark.hadoop.fs.s3a.path.style.access": "true",
    "spark.hadoop.fs.s3a.signing-algorithm": "S3SignerType",
    "spark.hadoop.fs.s3a.connection.ssl.enabled": "true",
    "spark.hadoop.fs.s3a.connection.timeout": "1200000",
    "spark.hadoop.fs.s3a.connection.maximum": "200",
    "spark.hadoop.fs.s3a.fast.upload": "true",
    "spark.hadoop.fs.s3a.readahead.range": "256K",
    "spark.hadoop.fs.s3a.input.fadvise": "random",
    "spark.hadoop.fs.s3a.impl": "org.apache.hadoop.fs.s3a.S3AFileSystem",

    "spark.driver.extraJavaOptions": "-Dcom.amazonaws.sdk.disableCertChecking=true -Djavax.net.ssl.trustStore=/opt/finalcacert/cacerts -Djavax.net.ssl.trustStorePassword=changeit",
    "spark.executor.extraJavaOptions": "-Dcom.amazonaws.sdk.disableCertChecking=true -Djavax.net.ssl.trustStore=/opt/finalcacert/cacerts -Djavax.net.ssl.trustStorePassword=changeit",

    "spark.extraListeners": "sparkmonitor.listener.JupyterSparkMonitorListener",
    "spark.driver.extraClassPath": "/opt/spark/jars/listener_2.12.jar", 

    "spark.sql.debug.maxTostringFields": "100",
    
    #"spark.submit.pyFiles": "external_functions.py",
    #"spark.files": "s3a://sphs/config/job_python.json,s3a://sphs/python/external_functions.py",
    "spark.jar.packages": "org.apache.spark:spark-sql-kafka-0-10_2.12:3.4.2",
    
}

def get_spark_session(app_name: str, conf: SparkConf):
    conf.setMaster("k8s://https://" + HOST + ":" + PORT )
    for key, value in config.items():
        conf.set(key, value)    
    return SparkSession.builder.appName(app_name).config(conf=conf).getOrCreate()