def multiply_by_two(n):
    return n * 2

def multiply_by_three(n):
    return n * 3

def concat(x):
    return "Julie " + x