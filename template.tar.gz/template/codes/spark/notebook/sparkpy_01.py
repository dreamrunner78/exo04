from ipynb.fs.full.sparkconf  import get_spark_session
from pyspark import SparkConf
from pyspark.sql import SparkSession

conf=SparkConf()
spark = get_spark_session("demo", conf)

print(conf.toDebugString())

df = spark.sparkContext.parallelize(range(50))
df.collect()

spark.stop()