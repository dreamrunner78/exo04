0.1.0

- Init support
- Modularized the directory structure
