#!/bin/bash

# Load environnement varaibles
. ./env.sh
. ./certs.sh

#PROXY
echo '************************ START ' $PREFIX ' PROXY ************************'
if [[ $enabledcpproxy == "true" ]]; then
    if kubectl get sts $releasemasterproxy -n $NAMESPACE &> /dev/null; then
        echo "============================= ' $PREFIX ' PROXY ALREADY INSTALLED ============================="
    else
        echo '=================================== CREATING' $PREFIX  ' PROXY ==================================='
        sed -e "s#{{PROXYNAME}}#$PROXYNAME#g;\
        s#{{NAMESPACE}}#$NAMESPACE#g;\
        s#{{NINXCLASS}}#$NINXCLASS#g;\
        s#{{SECRETNAME}}#$SECRETNAME#g;\
        s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\
        s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{PROXYSCHEDULERNAME}}#$PROXYSCHEDULERNAME#g;\

        s#{{COMMONLABELS}}#$COMMONLABELS#g;\
        s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\
        
        s#{{CERT_MANAGER_DNSNAMES}}#$CERT_MANAGER_DNSNAMES#g;\
        s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\

        s#{{PROXYREPLICACOUNT}}#$PROXYREPLICACOUNT#g;\
        s#{{PROXYSERVICEACCOUNT}}#$PROXYSERVICEACCOUNT#g;\
        s#{{RUNASUSER}}#$RUNASUSER#g;\

        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{PROXY_REPOSITORY}}#$PROXY_REPOSITORY#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\
        s#{{PROXY_VERSION}}#$PROXY_VERSION#g;\
        
        s#{{PROXYREQUESTCPU}}#$PROXYREQUESTCPU#g;\
        s#{{PROXYREQUESTMEMORY}}#$PROXYREQUESTMEMORY#g;\
        s#{{PROXYLIMITCPU}}#$PROXYLIMITCPU#g;\
        s#{{PROXYLIMITMEMORY}}#$PROXYLIMITMEMORY#g;\
        
        s#{{ENABLEINGRESS}}#$ENABLEINGRESS#g;\
        s#{{ENABLEOSROOT}}#$ENABLEOSROOT#g;\
        s#{{INGRESSHOSTNAME}}#$INGRESSHOSTNAME#g;\
        
        s#{{CACERT}}#$CACERT#g;\
        s#{{CAKEY}}#$CAKEY#g;\
        s#{{TLSCERT}}#$TLSCERT#g;\
        s#{{TLSKEY}}#$TLSKEY#g;" $yamltemplate/proxy-template.yaml > $yamldestination/proxy.yaml

        echo "certificate: |" >> $yamldestination/proxy.yaml
        echo "$CERTIFICATE" | while IFS= read -r line; do
            echo "  $line" >> $yamldestination/proxy.yaml
        done
        echo "key: |-" >> $yamldestination/proxy.yaml
        echo "$KEYCERT" | while IFS= read -r line; do
            echo "  $line" >> $yamldestination/proxy.yaml
        done

        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releasemasterproxy $repodir/master-proxy-appli --values $yamldestination/proxy.yaml
        fi

        #kubectl -n $NAMESPACE wait --for=condition=available --timeout=600s deployment.apps/master-proxy

        echo '===================================' $PREFIX ' PROXY CREATED ==================================='
    fi
else
    echo '===================================' $PREFIX ' PROXY DISABLED ==================================='
fi

echo '************************ END ' $PREFIX ' SCHEDULER ************************'