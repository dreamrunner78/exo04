#!/bin/bash

# Load environnement varaibles
. ./env.sh
. ./certs.sh


echo '************************START DCP STORAGE************************'
# create STORAGE
if [[ $enabledcpstorage == "true" ]]; then
    echo '----------------Create DCP STORAGE--------------------'
    sed -e "s#{{REGISTRY}}#$REGISTRY#g;\
    s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
    s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
    s#{{KUBEVERSION}}#$KUBEVERSION#g;\
    s#{{PULLPOLICY}}#$PULLPOLICY#g;\
    s#{{SECRETNAME}}#$SECRETNAME#g;\
    s#{{NINXCLASS}}#$NINXCLASS#g;\
    
    s#{{RUNASUSER}}#$RUNASUSER#g;\
    s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\

    s#{{COMMONLABELS}}#$COMMONLABELS#g;\
    s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\
    
    s#{{STORAGE_MODE}}#$STORAGE_MODE#g;\
    s#{{STORAGE_REPLICACOUNT}}#$STORAGE_REPLICACOUNT#g;\
    s#{{STORAGE_DRIVESPERNODE}}#$STORAGE_DRIVESPERNODE#g;\

    s#{{STORAGE_REPOSITORY}}#$STORAGE_REPOSITORY#g;\
    s#{{STORAGE_VERSION}}#$STORAGE_VERSION#g;\
    s#{{STORAGE_REPOSITORY_CLIENT}}#$STORAGE_REPOSITORY_CLIENT#g;\
    s#{{STORAGE_VERSION_CLIENT}}#$STORAGE_VERSION_CLIENT#g;\
    
    s#{{STORAGE_SSL_ENABLED}}#$STORAGE_SSL_ENABLED#g;\

    s#{{STORAGE_ACCESSKEY}}#$STORAGE_ACCESSKEY#g;\
    s#{{STORAGE_SECRETKEY}}#$STORAGE_SECRETKEY#g;\
    
    s#{{STORAGE_PERSISTNECE_ENABLED}}#$STORAGE_PERSISTNECE_ENABLED#g;\
    s#{{STORAGE_SIZE}}#$STORAGE_SIZE#g;\
    
    s#{{STORAGE_REQUESTCPU}}#$STORAGE_REQUESTCPU#g;\
    s#{{STORAGE_LIMITCPU}}#$STORAGE_LIMITCPU#g;\
    s#{{STORAGE_REQUESTMEMORY}}#$STORAGE_REQUESTMEMORY#g;\
    s#{{STORAGE_LIMITMEMORY}}#$STORAGE_LIMITMEMORY#g;\
    
    s#{{ENABLEINGRESS}}#$ENABLEINGRESS#g;\
    s#{{ENABLEOSROOT}}#$ENABLEOSROOT#g;\
    s#{{STORAGE_HOSTNAME}}#$STORAGE_HOSTNAME#g;" $yamltemplate/storage-template.yaml > $yamldestination/storage.yaml

    echo "certificate: |" >> $yamldestination/storage.yaml
    echo "$CERTIFICATE" | while IFS= read -r line; do
        echo "  $line" >> $yamldestination/storage.yaml
    done
    echo "key: |-" >> $yamldestination/storage.yaml
    echo "$KEYCERT" | while IFS= read -r line; do
        echo "  $line" >> $yamldestination/storage.yaml
    done

    if [[ $template == "false" ]]; then
        helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releasestorage $repodir/minio --values $yamldestination/storage.yaml
    fi

    #kubectl -n $NAMESPACE wait --for=condition=available --timeout=600s deployment.apps/dcp-storage-minio
    echo 'DCP storage created'
else
    echo 'DCP STORAGE NOT ENABLED'
fi
echo '************************END DCP STORAGE************************'
echo ''
echo ''