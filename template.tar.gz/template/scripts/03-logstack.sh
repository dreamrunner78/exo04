#!/bin/bash

# Load environnement varaibles
. ./env.sh
. ./certs.sh

echo '************************ START ' $PREFIX ' LOG STACK ************************'
#LOKI
if [[ $enablelogstack == "true" ]]; then
    if kubectl get sts $releaselogstack -n $NAMESPACE &> /dev/null; then
        echo '===================================' $PREFIX ' LOG STACK ALREADY INSTALLED ==================================='
    else
        echo '=================================== CREATING' $PREFIX ' LOG STACK ==================================='
        sed -e "s#{{LOKI_REPOSITORY}}#$LOKI_REPOSITORY#g;\
        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\
        s#{{LOKI_VERSION}}#$LOKI_VERSION#g;\
        s#{{LOKI_REQUEST_CPU}}#$LOKI_REQUEST_CPU#g;\
        s#{{LOKI_REQUEST_MEM}}#$LOKI_REQUEST_MEM#g;\
        s#{{LOKI_LIMIT_CPU}}#$LOKI_LIMIT_CPU#g;\
        s#{{LOKI_LIMIT_MEM}}#$LOKI_LIMIT_MEM#g;\
        s#{{LOKI_PERSISSTENCE_ENABLED}}#$LOKI_PERSISSTENCE_ENABLED#g;\
        s#{{LOKI_PERSISSTENCE_SIZE}}#$LOKI_PERSISSTENCE_SIZE#g;\
        s#{{LOKI_PERSISSTENCE_S3}}#$LOKI_PERSISSTENCE_S3#g;\
        s#{{PROMTAIL_REPOSITORY}}#$PROMTAIL_REPOSITORY#g;\
        s#{{PROMTAIL_VERSION}}#$PROMTAIL_VERSION#g;\
        s#{{PROMTAIL_DEPLOYMENT}}#$PROMTAIL_DEPLOYMENT#g;\
        s#{{PROMTAIL_DEPLOYMENT_REPLICAS}}#$PROMTAIL_DEPLOYMENT_REPLICAS#g;\
        s#{{PROMTAIL_REQUEST_CPU}}#$PROMTAIL_REQUEST_CPU#g;\
        s#{{PROMTAIL_REQUEST_MEM}}#$PROMTAIL_REQUEST_MEM#g;\
        s#{{PROMTAIL_LIMIT_CPU}}#$PROMTAIL_LIMIT_CPU#g;\
        s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
        s#{{RUNASUSER}}#$RUNASUSER#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{PROMTAIL_DAEMON}}#$PROMTAIL_DAEMON#g;\
        s#{{LOKI_ACCESS_KEY}}#$LOKI_ACCESS_KEY#g;\
        s#{{LOKI_SECRET_KEY}}#$LOKI_SECRET_KEY#g;\
        s#{{LOKI_S3_HOST}}#$LOKI_S3_HOST#g;\
        s#{{LOKI_BUCKET}}#$LOKI_BUCKET#g;\
        s#{{LOKKI_RETENTION_ENABLED}}#$LOKKI_RETENTION_ENABLED#g;\
        s#{{LOKI_COMPACTION_INTERVAL}}#$LOKI_COMPACTION_INTERVAL#g;\
        s#{{LOKI_RETENTION_DELETE_DELAY}}#$LOKI_RETENTION_DELETE_DELAY#g;\
        s#{{LOKI_RETENTION_PERIOD}}#$LOKI_RETENTION_PERIOD#g;\
        s#{{PROMTAIL_LIMIT_MEM}}#$PROMTAIL_LIMIT_MEM#g;" $yamltemplate/log-stack-template.yaml > $yamldestination/log-stack.yaml

        
        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releaselogstack $repodir/loki-stack --values $yamldestination/log-stack.yaml
        fi
        echo '===================================' $PREFIX ' LOG STACK CREATED ==================================='
    fi
else
    echo '===================================' $PREFIX ' LOG STACK DISABLED ==================================='
fi


#PROMTAIL
if [[ $createdcpgrafana == "true" ]]; then
    if kubectl get sts $GRAFANA_NAME -n $NAMESPACE &> /dev/null; then
        echo '=================================== $PREFIX ' Grafana installed ' ==================================='
    else
        echo '=================================== Create ' $PREFIX ' Grafana ==================================='
        sed -e "s#{{GRAFANA_NAME}}#$GRAFANA_NAME#g;\
        s#{{NAMESPACE}}#$NAMESPACE#g;\
        s#{{NINXCLASS}}#$NINXCLASS#g;\
        s#{{ISOPENSHIFT}}#$ISOPENSHIFT#g;\
        s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\
        s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\
        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{COMMONLABELS}}#$COMMONLABELS#g;\
        s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\
        s#{{RUNASUSER}}#$RUNASUSER#g;\
        s#{{ENABLEOSROOT}}#$ENABLEOSROOT#g;\
        s#{{ENABLEINGRESS}}#$ENABLEINGRESS#g;\
        s#{{INGRESSHOSTNAME}}#$INGRESSHOSTNAME#g;\
        s#{{GRAFANA_REPOSITORY}}#$GRAFANA_REPOSITORY#g;\
        s#{{GRAFANA_VERSION}}#$GRAFANA_VERSION#g;\
        s#{{GRAFANA_REQUEST_CPU}}#$GRAFANA_REQUEST_CPU#g;\
        s#{{GRAFANA_REQUEST_MEM}}#$GRAFANA_REQUEST_MEM#g;\
        s#{{GRAFANA_LIMIT_CPU}}#$GRAFANA_LIMIT_CPU#g;\
        s#{{GRAFANA_LIMIT_MEM}}#$GRAFANA_LIMIT_MEM#g;\
        s#{{GRAFANA_INGRESS_HOSTNAME}}#$GRAFANA_INGRESS_HOSTNAME#g;\
        s#{{GRAFANA_INGRESS_PATH}}#$GRAFANA_INGRESS_PATH#g;\
        s#{{PREFIX}}#$PREFIX#g;\
        s#{{CACERT}}#$CACERT#g;\
        s#{{CAKEY}}#$CAKEY#g;\
        s#{{TLSCERT}}#$TLSCERT#g;\
        s#{{TLSKEY}}#$TLSKEY#g;" $yamltemplate/grafana-template.yaml > $yamldestination/grafana.yaml

        echo "certificate: |" >> $yamldestination/grafana.yaml
        echo "$CERTIFICATE" | while IFS= read -r line; do
            echo "  $line" >> $yamldestination/grafana.yaml
        done
        echo "key: |-" >> $yamldestination/grafana.yaml
        echo "$KEYCERT" | while IFS= read -r line; do
            echo "  $line" >> $yamldestination/grafana.yaml
        done
        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $GRAFANA_NAME $repodir/grafana --values $yamldestination/grafana.yaml
        fi
        #kubectl -n $NAMESPACE wait --for=condition=available --timeout=600s deployment.apps/master-proxy
        echo '===================================' $PREFIX ' GRAFANA CREATED ==================================='
    fi
else
    echo '===================================' $PREFIX ' GRAFANA DISABLED ==================================='
fi

echo '************************ END ' $PREFIX ' LOG STACK ************************'