#!/bin/bash

# Load environnement varaibles
. ./env.sh

# echo '---------------- DELETE ' $PREFIX ' LOG STACH --------------------'
# helm -n $NAMESPACE uninstall $releaselogstack
# kubectl -n $NAMESPACE delete pvc --selector=release=$releaselogstack --wait=false

# echo '---------------- DELETE' $PREFIX ' GRAFANA --------------------'
# helm -n $NAMESPACE uninstall $GRAFANA_NAME

# echo '---------------- DELETE' $PREFIX ' REDIS --------------------'
# helm -n $NAMESPACE uninstall $releaseredis
# kubectl -n $NAMESPACE delete pvc --selector=app.kubernetes.io/instance=$releaseredis --wait=false

# echo '---------------- DELETE' $PREFIX ' SCHEDULER --------------------'
# helm -n $NAMESPACE uninstall $releasescheduler
# kubectl -n $NAMESPACE delete cm $releasescheduler-defaults
# kubectl -n $NAMESPACE delete cm yunikorn-defaults
# kubectl -n $NAMESPACE delete rolebinding releasescheduler-rbac
# kubectl -n $NAMESPACE delete role $releasescheduler
# kubectl -n $NAMESPACE delete sa dcpscheduler-admission-controller
# kubectl -n $NAMESPACE delete sa $releasescheduler-admin

#echo '---------------- DELETE' $PREFIX ' PROXY--------------------'
#helm -n $NAMESPACE uninstall $releasemasterproxy

#echo '----------------Delete DCP Databse--------------------'
#helm -n $NAMESPACE uninstall $releasepgs
#kubectl -n $NAMESPACE delete pvc --selector=app.kubernetes.io/instance=$releasepgs --wait=false

#kubectl -n $NAMESPACE delete -f $yamldestination/insert-Configmap.yaml
#kubectl -n $NAMESPACE delete -f $yamldestination/insert-Job.yaml
#kubectl -n $NAMESPACE delete job postgresql-job

echo '----------------Delete DCP API--------------------'
helm -n $NAMESPACE uninstall $releasemaster
kubectl -n $NAMESPACE delete pvc --selector=app.kubernetes.io/instance=$releasemaster --wait=false

#echo '----------------Delete DCP Secret--------------------'
#helm -n $NAMESPACE uninstall $SECRETNAME

